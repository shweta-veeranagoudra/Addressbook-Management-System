#include <stdio.h>
#include "file.h"

void saveContactsToFile(AddressBook *addressBook) 
{
    FILE *fp;
    int i ;
    fp = fopen("contacts.csv","w");
    if(fp == NULL)
    {
        perror("fopen");
        return ;
    }

    fprintf(fp,"%d\n",addressBook->contactCount);
    for( i = 0 ; i < addressBook->contactCount ; i++)
    {
      fprintf(fp,"%s,%s,%s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
    }
    fclose(fp);
    return ;

}

void loadContactsFromFile(AddressBook *addressBook) 
{
   FILE *fp;
   fp = fopen("contacts.csv","r");
   if(fp == NULL)
   {
      perror("fopen");
      return ;
   }
   fscanf(fp,"%d\n",&addressBook->contactCount);
   int i = 0 ;
   while( i < addressBook->contactCount )
   {
      fscanf(fp,"%[^,],%[^,],%[^\n]\n", addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
      i++ ;
   }
   fclose(fp);
}
