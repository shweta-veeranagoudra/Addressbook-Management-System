#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
//#include "populate.h"

// list contacts ------------------------------------------

void list_name(AddressBook *addressBook)
{
    int i , j ;
    Contact temp ;
    for ( i = 0 ; i <addressBook->contactCount ; i++)
    {
         for ( j = 0 ; j < addressBook->contactCount - i -1  ; j++)
         {
            if( strcasecmp(addressBook->contacts[j].name, addressBook->contacts[j+1].name) > 0)
            {
                temp = addressBook->contacts[j] ;
                addressBook->contacts[j] = addressBook->contacts[j+1] ;
                addressBook->contacts[j+1] = temp ;
            }
         }
    }

    printf("---------------------------------------------------------------------------\n");
    printf("\033[35m|%-5s | %-20s | %-12s | %-20s |\033[0m\n" ,"S.NO" ,"Name","Phone_Number","Email" );
    printf("---------------------------------------------------------------------------\n");
    for( i = 0 ; i < addressBook->contactCount ; i++  )
    {
      printf("\033[36m| %-5d | %-20s | %-12s | %-20s|\033[0m\n",i+1,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
    }
    printf("---------------------------------------------------------------------------\n");
   
}
void list_email(AddressBook *addressBook)
{
    int i , j ;
    Contact temp ;
    for ( i = 0 ; i <addressBook->contactCount ; i++)
    {
         for ( j = 0 ; j < addressBook->contactCount - i -1  ; j++)
         {
            if( strcasecmp(addressBook->contacts[j].email, addressBook->contacts[j+1].email) > 0)
            {
                temp = addressBook->contacts[j] ;
                addressBook->contacts[j] = addressBook->contacts[j+1] ;
                addressBook->contacts[j+1] = temp ;
            }
         }
    }

    printf("---------------------------------------------------------------------------\n");
    printf("\033[35m|%-5s | %-20s | %-12s | %-20s |\033[0m\n" ,"S.NO" ,"Name","Phone_Number","Email" );
    printf("---------------------------------------------------------------------------\n");
    for( i = 0 ; i < addressBook->contactCount ; i++  )
    {
      printf("\033[36m| %-5d | %-20s | %-12s | %-20s|\033[0m\n",i+1,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
    }
    printf("---------------------------------------------------------------------------\n");
   
}
void list_phone(AddressBook *addressBook)
{
    int i , j ;
    Contact temp ;
    for ( i = 0 ; i <addressBook->contactCount ; i++)
    {
         for ( j = 0 ; j < addressBook->contactCount - i -1  ; j++)
         {
            if( strcmp(addressBook->contacts[j].phone, addressBook->contacts[j+1].phone) > 0)
            {
                temp = addressBook->contacts[j] ;
                addressBook->contacts[j] = addressBook->contacts[j+1] ;
                addressBook->contacts[j+1] = temp ;
            }
         }
    }

    printf("---------------------------------------------------------------------------\n");
    printf("\033[35m|%-5s | %-20s | %-12s | %-20s |\033[0m\n" ,"S.NO" ,"Name","Phone_Number","Email" );
    printf("---------------------------------------------------------------------------\n");
    for( i = 0 ; i < addressBook->contactCount ; i++  )
    {
      printf("\033[36m| %-5d | %-20s | %-12s | %-20s|\033[0m\n",i+1,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
    }
    printf("---------------------------------------------------------------------------\n");
   
}

void listContacts(AddressBook *addressBook) 
{   
   printf("\033[33mList Menu\033[0m\n");
   printf("\033[32m1.List by Name\n");
   printf("2.list by Email\n");
   printf("3.list by Phone Number\033[0m\n");
   int opt ;
   printf("Enter the option :");
   scanf(" %d",&opt);

   switch(opt)
   {
     case 1 :
                list_name(addressBook);
                break ;
     case 2 :
                list_email(addressBook);
                break ;
     case 3 :
                list_phone(addressBook);
                break ;
     default:
                printf("\033[33mEntered option doest not Exist \033[0m\n");
   }


}

void initialize(AddressBook *addressBook) {
    addressBook->contactCount = 0;
    //populateAddressBook(addressBook);

    // Load contacts from file during initialization (After files)
    loadContactsFromFile(addressBook);
}

void saveAndExit(AddressBook *addressBook) 
{
    saveContactsToFile(addressBook); // Save contacts to file
    exit(EXIT_SUCCESS); // Exit the program
}

// ---------------------------- CREATE CONTACT------------------------------------------------------------//
int validate_name(char *name)
{
    
    int i = 0 ;

    while ( name[i] != '\0')
    {
        if (!(( name[i] >= 'a' && name[i]<= 'z') || ( name[i] >= 'A' && name[i]<= 'Z') || (name[i] == ' ') || (name[i] == '.')))
        {   
            printf("\033[33mEnter valid name ( alphabets ,' ', . )\033[0m\n");
            return 0 ;
        }
        i++ ;
    }
    return 1 ;
    
}

int validate_phone(AddressBook *addressBook,char *str)
{   
    int i = 0 ;

    if ( strlen(str)!= 10)
    {
        printf("\033[33m Entera a valid phone number(10 digits only !)\033[0m\n");
        return 0 ;
    }

    while ( str[i] != '\0')
    {
        if (!(( str[i] >= '0' && str[i]<= '9') ))
        {  
            printf("\033[33m Entera a valid phone number(0 - 9)\033[0m");
            return 0 ;
        }
        i++ ;
    }

    for(i = 0; i < addressBook->contactCount; i++)
    {
        if ( strcmp (addressBook->contacts[i].phone ,str ) == 0 )
        {
            printf("\033[33m!!!The Entered number Already Exists!!!\033[0m\n");
            return 0 ;
        }
    }
    return 1 ;
}

int validate_mail(AddressBook *addressBook, char *str)
{   
    int i = 0 ;
    int flag_at = 0 ;
    int index ;
 
    if(!(( str[0] >= 'a' && str[0]<= 'z') || ( str[0] >= 'A' && str[0]<= 'Z')))
    {   
        printf("\033[33mPlease Enter Valid  Email id\033[33m\n");
        return  0 ;
    }

    if( !(strstr(str,".com")))
    {   
        printf("\033[33m!!!please  Enter valid email extension ex : mail.com !!!\033[0m\n");
            return 0 ;
    }
    
    while ( str[i] != '\0')
    {
        if(str[i] == '@')
        {
            flag_at = 1 ;
            index = i ;
        }
        i++ ;
    }

    if(flag_at == 0)
    {
        printf("\033[33m!! Enter a proper email id with '@' !!\033[0m\n ");
        return 0 ;
    }

    if (strcmp(&str[index+1],"mail.com")==0 || strcmp(&str[index+1],".com") == 0)
    {   
        printf("\033[33mPlease enter email  with valid domain name\033[0m\n");
        return 0 ;
    }

   
    for(i = 0; i < addressBook->contactCount; i++)
    {
        if ( strcmp (addressBook->contacts[i].email ,str ) == 0 )
        {
            printf("\033[33m!!!The Entered mail Already Exists!!!\033[0m\n");
            return 0 ;
        }
    }

    return 1 ;
}

void createContact(AddressBook *addressBook)
{

    char name[20];
    int valid;

    while(1)
    {
        printf("Enter the name : ");
        scanf(" %[^\n]", name);

        valid = validate_name(name);
        if(valid == 1)
            break;
    }

    char mobile[11];

    while(1)
    {
        printf("Enter the phone : ");
        scanf("%s", mobile);

        valid = validate_phone(addressBook,mobile);
        if(valid == 1)
            break;
    }

    char mail[30];

    while(1)
    {
        printf("Enter the mail : ");
        scanf(" %[^\n]", mail);

        valid = validate_mail(addressBook,mail);
        if(valid == 1)
            break;
    }

    strcpy(addressBook->contacts[addressBook->contactCount].name, name);

    strcpy(addressBook->contacts[ addressBook->contactCount].phone, mobile);

    strcpy(addressBook->contacts[ addressBook->contactCount].email, mail);


    addressBook->contactCount++;

    
}

// -------------------------- SEARCHING -------------------------------------------------------------//
int search_phone(AddressBook *addressBook)
{   
    char search[11];
    int i ;
    printf("Enter the phone number :");
    scanf(" %[^\n]",search);
    for( i = 0 ; i < addressBook->contactCount ; i++  )
    {
        if( strcmp (addressBook->contacts[i].phone, search) == 0)
        {   
            printf("\033[35m| %-5d | %-20s | %-12s | %-20s|\033[0m\n",i+1,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
            
            return i;
        }
    }


    printf("\033[31m!! phone Number Not Found !!\033[0m\n");
            
    return -1;
        
}

int search_name(AddressBook *addressBook)
{   
    char search[50];
    int i  ;
    printf("Enter the name :");
    scanf(" %[^\n]",search);
    int count = 0 ;
    int index ;

    for( i = 0 ; i < addressBook->contactCount ; i++  )
    {
        if( strcmp (addressBook->contacts[i].name, search) == 0)
        {   
             count++ ;
             index = i ;

        }
    }

    if( count == 0)
    {
        printf("\033[31m!! Name Not Found !!\033[0m\n");
        return -1 ;
            
    }
    else if( count == 1)
    {
        printf("\033[35m| %-5d | %-20s | %-12s | %-20s|\033[0m\n",index+1,addressBook->contacts[index].name,addressBook->contacts[index].phone,addressBook->contacts[index].email);
        return index ;
    }

    if ( count > 1)
    {   
        return search_phone(addressBook) ;
    }
    

        
}
int  search_email(AddressBook *addressBook)
{   
    char search[50];
    int i ,index = -1 ;
    printf("Enter the email:");
    scanf(" %[^\n]",search);
    for( i = 0 ; i < addressBook->contactCount ; i++  )
    {
        if( strcmp (addressBook->contacts[i].email, search) == 0)
        {   
            printf("\033[35m| %-5d | %-20s | %-12s | %-20s|\033[0m\n",i+1,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
            return i ;
        }
    }
    
    printf("\033[31m!! Email Not Found \033[0m!!\n");
    return -1 ;
        
}

void searchContact(AddressBook *addressBook) 
{
    printf("\033[33mSearch Menu\033[0m\n");
    printf("\033[34m1.Search By name\n");
    printf("2.Search By mobilenumber\n");
    printf("3.Search By email\033[0m\n");

    int option ;
    printf("Enter your choice :");
    getchar();
    scanf("%d",&option);

    switch(option)
    {   
        case 1 :  
                search_name(addressBook);
                break ;       
        case 2 :        
                search_phone(addressBook);
                break ;               
        case 3 :         
                search_email(addressBook);
                break ;              
        default :
                printf("\033[31m In valid choice \033[0m\n");
                return  ;
                
    }
   
}

//----------------------EDITING-------------------------------------------------------------------------//

void edit_name(AddressBook *addressBook)
{    
    int  res , i ,valid;
    char str_edit[50] ;
    char name[50];
    
    res = search_name(addressBook);
    if ( res == -1)
    {
        printf("\033[31mContact Not found to edit\033[0m");
        return ;
    }
    while(1)
    {   
        printf("Enter a new name:");
        scanf(" %[^\n]",name);
        valid = validate_name(name);
        if(valid)
        {
            strcpy(addressBook->contacts[res].name, name);
            printf("\033[32m ***** UPDATED SUCCESSFULLY ***** \033[0m");
            return ;

        }
        else
        {
            printf("\033[33m!! Enter a valid name !!\033[0m\n");
        }
    }


}
void edit_phone(AddressBook *addressBook)
{
    int res , i ,valid;
    char str_edit[50] ;
    char phone[50];
    res = search_phone(addressBook);
    if ( res == -1)
    {
        printf("\033[31mContact Not found to edit\033[0m");
        return ;
    }
  
   
    while(1)
    {   
        printf("Enter a new Phone number:");
        scanf(" %[^\n]",phone);
        valid =  validate_phone(addressBook,phone);
        if(valid)
        {
            strcpy(addressBook->contacts[res].phone,phone);
            printf("\033[32m ***** UPDATED SUCCESSFULLY ***** \033[0m");
            return ;

        }
        else
        {
            printf("\033[33m!! Enter a valid Phone Number !!\033[0m\n");
        }
    }

}

void edit_email(AddressBook *addressBook)
{
    int res, i ,valid;
    char str_edit[50] ;
    char email[50];

    res = search_email(addressBook);
    if ( res == -1)
    {
        printf("\033[31mContact Not found to edit\033[0m");
        return ;
    }
   
    while(1)
    {   
        printf("Enter a new Email ID:");
        scanf(" %[^\n]",email);
        valid =  validate_mail(addressBook,email);
        if(valid)
        {
            strcpy(addressBook->contacts[res].email,email);
            printf("\033[32m***** UPDATED SUCCESSFULLY ***** \033[0m");
            return ;

        }
        else
        {
            printf("\033[33m!! Enter a valid Email ID !!\033[0m\n");
        }
    }

}

void editContact(AddressBook *addressBook)
{
	printf("\033[33mChoose the field u want to edit\033[0m\n");
    printf("\033[34m1.name\n");
    printf("2.mobilenumber\n");
    printf("3.email\033[0m\n");

    int option ;
    printf("Enter your choice :");
    scanf(" %d",&option);

    switch(option)
    {   
        case 1 :  
                edit_name(addressBook);
                break ;
              
        case 2 :
               
                edit_phone(addressBook);
                break ;
                       
        case 3 :
               
                edit_email(addressBook);
                break ;
                   
        default :
                printf("\033[33mEnter a valid choice ( 1, 2, 3)\033[0m\n");
    }

}

//--------------------------------------------DELETING-------------------------------------------------//
void delete(int index ,AddressBook *addressBook)
{   
    int i ;
    for( i = index ; i < (addressBook->contactCount)-1 ; i++)
    {   

        addressBook->contacts[i] = addressBook->contacts[i+1] ;
       
    }
    addressBook->contactCount -- ;
  
}
void delete_phone(AddressBook *addressBook)
{
    int res;

    res = search_phone(addressBook);
    if ( res != -1)
    {
        delete( res ,addressBook);
    }

    if(  res ==  -1)
    {
         printf("\033[31m!! Entered Name not found to delete !!\033[0m");
         return ;
    }
    printf(" \033[32m***** DELETED SUCESSFULLY *****\033[0m ");

}
void delete_name(AddressBook *addressBook)
{  

    int res;

    res = search_name(addressBook);
    if ( res != -1)
    {   
        delete( res ,addressBook);
    }

    if(  res ==  -1)
    {
         printf("\033[31m!! Entered Name not found to delete !!\033[0m");
         return ;
    }
    printf("\033[32m ***** DELETED SUCESSFULLY *****\033[0m ");
}

void delete_email(AddressBook *addressBook)
{
    int res;
    res = search_email(addressBook);
    if ( res != -1)
    {
        delete( res ,addressBook);
    }

    if(  res ==  -1)
    {
         printf("\033[31m!! Entered Name not found to delete !!\033[0m");
    }
    printf("\033[32m ***** DELETED SUCESSFULLY ***** \033[0m");

}

void deleteContact(AddressBook *addressBook)
{
	printf("\033[33mDELETE MENU\033[0m\n");
    printf("\033[34m1.delete by Name\n");
    printf("2.delete by phonenumber\n");
    printf("3.delete by email\033[0m\n");

    int option ;
    printf("Enter your choice :\n");
    scanf(" %d",&option);

    switch(option)
    {   
        case 1 :  
                delete_name(addressBook);
                break ;
              
        case 2 :            
                delete_phone(addressBook);
                break ;
                       
        case 3 :        
                delete_email(addressBook);
                break ;
                   
        default :
                printf("\033[33mEnter a valid choice ( 1, 2, 3)\033[0m\n");
    }
}